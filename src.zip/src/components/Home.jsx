import React from "react";
import axios from "axios";
import css from "../styles/home.module.css";
import { useState } from "react";
import { useEffect } from "react";
import MovieBlock from "./MovieBlock";
import SearchBtn from "./tools/Search";
import BigMovie from "./BigMovie/BigMovie";
import { useSelector } from "react-redux";
import {
  requestMovies,
  setMovies,
  setRecomendations,
} from "../store/HomeSlice";
import { useDispatch } from "react-redux";
import SingleMovie from "./SingleMovie";
import MovieBlockPreloader from "./tools/MovieBlockPreloader";
import Recomended from "./Recomended";
import { requestFavorites } from "../store/FavoritesSlice";

export const API_Key = "90a2d91e59493255d0f5b07d7bb87d05";

const Home = (props) => {
  const dispatch = useDispatch();
  const array = [1, 2, 3, 4];
  const { isLogged } = useSelector((state) => state.login);
  const UserID = useSelector((state) => state.login.account.uid);
  const [modalWindow, setModalWindow] = useState(false);
  const { movies, loadingStatus, recomended } = useSelector(
    (state) => state.home
  );
  const { searchString } = useSelector((state) => state.filter);

  useEffect(() => {
    console.log("yes");
    dispatch(requestMovies(searchString));
  }, [searchString]);

  useEffect(() => {
    dispatch(requestFavorites(UserID));
  }, [isLogged]);

  useEffect(() => {
    axios
      .get(
        `https://api.themoviedb.org/3/trending/all/week?api_key=${API_Key}&language=en-US`
      )
      .then((response) => {
        dispatch(setMovies(response.data.results));
        //console.log(response);
      });
  }, []);

  const handleClick = () => {
    setModalWindow(!modalWindow);
  };

  return (
    <div className={css.home}>
      <BigMovie />

      <div className={css.wrapper}>
        <div onClick={handleClick} className={css.filters}>
          FILTERS
        </div>{" "}
        {modalWindow && (
          <div className={css.popUp}>
            <ul>
              <li>Gengre</li>
              <li></li>
              <li></li>
            </ul>
          </div>
        )}
        <div className={css.movieBlock}>
          {loadingStatus === "pending"
            ? array.map((x) => <MovieBlockPreloader />) // "LOADING..."
            : movies.map((movieData) => {
                return (
                  <MovieBlock
                    movieData={movieData}
                    key={movieData.id}
                    selectMovie={() => {}}
                  />
                );
              })}
        </div>
      </div>
      <Recomended />
    </div>
  );
};

export default Home;

// useEffect(() => {
//   axios
//     .get(
//       `https://api.themoviedb.org/3/discover/tv?api_key=${API_Key}&language=en-US&sort_by=popularity.desc`
//     )
//     .then((response) => {
//       dispatch(setRecomendations(response.data.results));
//       //console.log(response);
//     });
// }, []);

{
  /* <div className={css.movieBlock}>
        Recomended 4 you!
        {loadingStatus === "pending"
          ? "LOADING..."
          : recomended.map((movieData) => {
              return <MovieBlock movieData={movieData} key={movieData.id} />;
            })}
      </div> */
}
