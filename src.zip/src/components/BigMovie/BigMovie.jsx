import React, { useEffect, useState } from "react";
import css from "./BigMovie.module.css";
import axios from "axios";
import { API_Key } from "../Home";
import { setMustWatch } from "../../store/HomeSlice";
import { useDispatch, useSelector } from "react-redux";
import MovieBlock from "../MovieBlock";
import BigMovieLoader from "../tools/HomePreloader";
import {
  addToFavoritesThunk,
  requestFavorites,
  resetStatus,
} from "../../store/FavoritesSlice";
import TrailerBlock from "../tools/TrailerBlock";
import { requestTrailerURL } from "../../api/api";
import { MyNotification } from "../tools/MyNotification";

// {movies[2]}
const BigMovie = () => {
  const dispatch = useDispatch();
  const [selectedMovie, setSelectedMovie] = useState(null);
  const { mustWatchList } = useSelector((state) => state.home);

  useEffect(() => {
    axios
      .get(
        `https://api.themoviedb.org/3/discover/movie?api_key=${API_Key}&language=en-US&sort_by=popularity.desc`
      )
      .then((response) => {
        dispatch(setMustWatch(response.data.results));
        //console.log(response);
      });
  }, []);

  return (
    <div className={css.container}>
      {selectedMovie && (
        <ShowDisplay
          mustWatchList={mustWatchList}
          selectedMovie={selectedMovie}
        />
      )}

      <div className={css.movieList}>
        {mustWatchList.map((x, i) => {
          return <MovieBlock movieData={x} selectMovie={setSelectedMovie} />;
        })}
      </div>
    </div>
  );
};

const ShowDisplay = ({ selectedMovie, mustWatchList }) => {
  const dispatch = useDispatch();
  const UserID = useSelector((state) => state.login.account.uid);
  const { actionSuccess } = useSelector((state) => state.favorites);
  let neededMovie = mustWatchList.find((movie) => movie.id === selectedMovie);
  const status = useSelector((state) => state.favorites.status);
  const [showNotification, setShowNotification] = useState(false);

  useEffect(() => {
    if (status === "success") {
      setShowNotification(true);

      dispatch(resetStatus());
    } else if (status === "error") {
      //showNotification("Failed to add movie to favorites");

      dispatch(resetStatus());
    }
  }, [status]);

  const addToWatchList = () => {
    dispatch(
      addToFavoritesThunk({ UserID: UserID, selectedMovie: selectedMovie })
    );
    dispatch(requestFavorites(UserID));
  };
  const [TrailerURL, setTrailerURL] = useState("");

  useEffect(() => {
    const getURL = async (id) => {
      const vidURL = await requestTrailerURL(id);
      setTrailerURL(vidURL);
    };
    getURL(neededMovie.id);
  }, [selectedMovie]);

  console.log(TrailerURL);

  // const [isAuto, setAuto] = useState(false);
  //onClick = { addToWatchList };  isAuto={isAuto}  onClick={setAuto(!isAuto)}

  return (
    <div className={css.BigMovie}>
      <div className={css.filmPoster}>
        <div className={css.pic}>
          <img
            src={`http://image.tmdb.org/t/p/w500/${neededMovie.poster_path}`}
          />
          <div className={css.textValues}>
            <h2> {neededMovie.title}</h2>
            <div className={css.description}>{neededMovie.overview}</div>
            <div className={css.buttons}>
              <div className={css.watch}>Watch</div>
              <div className={css.myList}>My List</div>
              {showNotification && (
                <MyNotification message="Movie added to favorites successfully" />
              )}
            </div>
          </div>
        </div>
      </div>
      <div className={css.youTube}>
        <TrailerBlock trailerURL={TrailerURL} />
      </div>
    </div>
  );
};

export default BigMovie;
