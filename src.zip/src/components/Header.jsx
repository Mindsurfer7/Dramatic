import React, { useState } from "react";
import css from "../styles/header.module.css";
import axios from "axios";
import { useEffect } from "react";
import { movieAPI } from "../api/api";
import SearchBtn from "./tools/Search";
import { NavLink } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { loginWithGoogle } from "../store/LoginSlice";
import logo from "../pics/dramatic.png";

const Header = (props) => {
  const { isLogged } = useSelector((state) => state.login);
  const { displayName } = useSelector((state) => state.login.account);
  const [isVisible, setVisible] = useState();
  const dispatch = useDispatch();

  const loginSubmit = () => {
    dispatch(loginWithGoogle());
  };

  return (
    <header className={css.header}>
      <div className={css.container}>
        <NavLink to={"/"}>
          <div className={css.logo}>
            <img src={logo} />
          </div>
        </NavLink>
        <nav className={css.menu}>
          <ul className={css.list}>
            <li>
              <NavLink to={"/"} className={css.link}>
                Home
              </NavLink>
            </li>
            <li>
              <NavLink to={""} className={css.link}>
                TV Show
              </NavLink>
            </li>
            <li>
              <NavLink to={""} className={css.link}>
                Movies
              </NavLink>
            </li>
            <li>
              <NavLink to={""} className={css.link}>
                News
              </NavLink>
            </li>
          </ul>
        </nav>
        <SearchBtn />
        {isLogged ? (
          <div
            className={css.nickname}
            onClick={() => {
              setVisible(!isVisible);
            }}
          >
            {displayName}
          </div>
        ) : (
          <div className={css.login} onClick={loginSubmit}>
            LOGIN
          </div>
        )}
        {isVisible ? (
          <div className={css.account}>
            <NavLink to={"/favorites"}>
              <div className={css.WatchList}>Favorites</div>
            </NavLink>
          </div>
        ) : (
          ""
        )}
      </div>
    </header>
  );
};

export default Header;
//"https://api.themoviedb.org/3/movie/550?api_key=90a2d91e59493255d0f5b07d7bb87d05"
