import React, { useEffect } from "react";
import { API_Key } from "./Home";
import MovieBlockPreloader from "./tools/MovieBlockPreloader";
import MovieBlock from "./MovieBlock";
import { useDispatch, useSelector } from "react-redux";
import { requestRecMovies } from "../store/RecomendedSlice";
import css from "../styles/recomend.module.css";
import { requestFavorites } from "../store/FavoritesSlice";

const Recomended = ({ movieData, selectMovie }) => {
  const dispatch = useDispatch();
  const array = [1, 2, 3, 4];
  const UserID = useSelector((state) => state.login.account.uid);
  const { favorites } = useSelector((state) => state.favorites);
  const { recomendations, loadingStatus } = useSelector(
    (state) => state.recomended
  );

  useEffect(() => {
    dispatch(requestFavorites(UserID));

    let movieID = favorites[0]; //просто первый фильм из избранного

    dispatch(requestRecMovies({ movieID }));
  }, [favorites.length]);

  return (
    <div className={css.wrapper}>
      {!UserID && (
        <h1 className={css.caution}>
          Please, log in to get personal recomendations
        </h1>
      )}

      {favorites.length > 0 && <h2>Recomended 4 you!</h2>}

      <div className={css.recContainer}>
        {loadingStatus === "pending" ? (
          <div className={css.caution}>
            <span>Please, log in to get personal recomendations</span>
            ADD FAVORITES TO GET RECOMENDATIONS BASED ON YOUR INTERESTS
          </div>
        ) : (
          recomendations.map((movieData) => {
            return (
              <MovieBlock
                movieData={movieData}
                key={movieData.id}
                selectMovie={() => {}}
              />
            );
          })
        )}
      </div>
    </div>
  );
};

export default Recomended;

// array.map((x) => <MovieBlockPreloader />)// "LOADING..."
