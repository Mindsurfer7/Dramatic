import YouTube from "react-youtube";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { API_Key } from "../Home";

const TrailerBlock = ({ trailerURL, isAuto }) => {
  // const videoOptions = {
  //   playerVars: {
  //     autoplay: isAuto,
  //   },
  // };
  // opts = { videoOptions };

  return trailerURL && <YouTube videoId={trailerURL} />;
};
export default TrailerBlock;
