import React, { useEffect, useState } from "react";
import css from "../../styles/home.module.css";

export const MyNotification = ({ message }) => {
  const [visible, setVisible] = useState(true);
  console.log(message);
  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
    }, 3000);

    return () => {
      clearTimeout(timer);
    };
  }, []);

  return visible ? <div className={css.notification}>{message}</div> : null;
};
