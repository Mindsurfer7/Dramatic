import React, { useState } from "react";
import css from "../styles/singlemovie.module.css";
import axios from "axios";
import { useEffect } from "react";
import { useParams } from "react-router-dom";
import { API_Key } from "./Home";
import { useDispatch } from "react-redux";

import { setMovieData } from "../store/SingleMovieSlice";
import { useSelector } from "react-redux";
import TrailerBlock from "./tools/TrailerBlock";

const SingleMovie = (props) => {
  const dispatch = useDispatch();
  const { ID } = useParams();
  const { movieData } = useSelector((state) => state.singleMovie);
  const [trailerURL, setTrailerURL] = useState("");

  useEffect(() => {
    axios
      .get(
        `https://api.themoviedb.org/3/movie/${ID}?api_key=${API_Key}&append_to_response=videos`
      )
      .then((response) => {
        console.log(response.data);

        dispatch(setMovieData(response.data));

        const officialTrailer = response.data.videos.results.find(
          (video) => video.type === "Trailer" //Official T
        );
        if (officialTrailer) {
          setTrailerURL(officialTrailer.key);
        }
      });
  }, [ID]);

  console.log(trailerURL);

  return (
    movieData && (
      <div className={css.container}>
        <div className={css.imgAndTitle}>
          <div>
            <img
              src={`http://image.tmdb.org/t/p/w500/${movieData.poster_path}`}
            />
          </div>

          <div className={css.title}>{movieData.title}</div>
          <div className={css.overview}>{movieData.overview}</div>
        </div>

        <span>Год: {movieData.release_date}</span>
        <div>
          Жанры:{" "}
          {movieData.genres && movieData.genres.map((x) => `${x.name}, `)}{" "}
        </div>

        <div>Rating: {movieData.vote_average}</div>
        <TrailerBlock trailerURL={trailerURL} />
      </div>
    )
  );
};

export default SingleMovie;
