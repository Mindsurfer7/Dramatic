import css from "../Footer/footer.module.css";

const Footer = () => {
  return (
    <div className="wrapper">
      <div className={css.language}></div>
      <div className={css.nav}>
        <ul>
          <li>Home</li>
          <li>FAQ</li>
          <li>Investor Relatins</li>
          <li>Jobs</li>
          <li>About Us</li>
          <li>Help Center</li>
        </ul>
      </div>
      <div className={css.legal}>
        <ul>
          <li>Privacy Policy</li>
          <li>Terms of service</li>
          <li>Cookie Preferences</li>
          <li>Corporate Information</li>
        </ul>
      </div>
      <div className={css.talk}></div>
      <div className={css.social}></div>
    </div>
  );
};

export default Footer;
