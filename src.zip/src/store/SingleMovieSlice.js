import { PayloadAction, createSlice } from "@reduxjs/toolkit";

// type FilterReducer = {
//   categoryID: number;
//   currentPage: number;
//   searchString: string;
//   sort: SortItem;
// };
const initialState = {
  movieData: {},
};

export const SingleMovieSlice = createSlice({
  name: "singleMovie",
  initialState,
  reducers: {
    setMovieData: (state, action) => {
      state.movieData = action.payload;
    },
  },
});

export const { setMovieData } = SingleMovieSlice.actions;

export default SingleMovieSlice.reducer;
