import { PayloadAction, createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { addToFavoritesAPI } from "../api/api";
import { API_Key } from "../components/Home";

//simple search `https://api.themoviedb.org/3/search/movie?api_key=${API_Key}&query=${searchString}`

//genres list https://api.themoviedb.org/3/genre/tv/list?api_key=90a2d91e59493255d0f5b07d7bb87d05&language=en-US

// multi search https://api.themoviedb.org/3/search/multi?api_key=${API_Key}&query=${searchString}

export const requestMovies = createAsyncThunk(
  "home/requestMovies",
  async (searchString) => {
    const { data } = await axios.get(
      `https://api.themoviedb.org/3/search/movie?api_key=${API_Key}&query=${searchString}`
    );
    console.log(data);
    return data.results;
  }
);

const initialState = {
  movies: [],
  mustWatchList: [],
  recomended: [],
  loadingStatus: "pending",
};

export const homeReducer = createSlice({
  name: "home",
  initialState,
  reducers: {
    setMovies: (state, action) => {
      state.movies = action.payload;
    },
    setRecomendations: (state, action) => {
      state.recomended = action.payload;
    },
    setMustWatch: (state, action) => {
      state.mustWatchList = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(requestMovies.fulfilled, (state, action) => {
      state.movies = action.payload;
      state.loadingStatus = "success";
    });

    builder.addCase(requestMovies.rejected, (state, action) => {
      state.loadingStatus = "error";
      console.log("API error");
    });
    builder.addCase(requestMovies.pending, (state, action) => {
      state.loadingStatus = "pending";
    });
  },
});

export const { setMovies, setRecomendations, setMustWatch } =
  homeReducer.actions;

export default homeReducer.reducer;

// type request = Record<string, string>;

// type HomeReducer = {
//   pizzas: PizzaBlockProps[];
//   loadingStatus: "pending" | "success" | "error";
// };

// enum Status {
//   PENDING = "pending",
//   SUCCESS = "success",
//   ERROR = "error",
// }
// export const requestMovies = createAsyncThunk(
//   "home/requestMovies",
//   async (params) => {
//     const { searchString } = params;
//     const { data } = await axios.get(
//       `https://api.themoviedb.org/3/search/movie?api_key=90a2d91e59493255d0f5b07d7bb87d05&query=${searchString}`
//     );
//     console.log(data);
//     return data;
//   }
// );
